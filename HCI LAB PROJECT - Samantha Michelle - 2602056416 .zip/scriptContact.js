var fullname = document.getElementById('fullname')
var email = document.getElementById('email')
var phone = document.getElementById('phone')
var pref = document.getElementById('pref')
var agreement = document.getElementById('agreement')

function checkNum(phone){
    for(var i=0; i<phone.length; i++){
        var ascii = phone.charCodeAt(i)
        if(ascii<48 || ascii>57) return false
    }
    return true
}

function checkInputs(){
    if(fullname.value == ''){
        alert('Please input your name')
    }else if(!email.value.endsWith('@gmail.com')){
        alert('Email must ends with @gmail.com')
    }else if(!checkNum(phone.value)){
        alert('Phone number must be digits')
    }else if(phone.value.length > 13 && phone.value.length < 7){
        alert('Phone number must be 7-13 digits')
    }else if(!agreement.checked){
        alert('Agreement box must be checked')
    }else{
        confirm('Form successfully sent!')
        form.reset()
    }
}